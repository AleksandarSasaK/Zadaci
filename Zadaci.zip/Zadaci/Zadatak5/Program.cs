﻿using System;
class Program
{
    static void Main()
    {
        Console.Write("Unesite broj: ");
        int broj = Convert.ToInt32(Console.ReadLine());

        if (broj > 0)
        {
            Console.WriteLine("Broj je pozitivan.");
        }
        else if (broj < 0)
        {
            Console.WriteLine("Broj je negativan.");
        }
        else
        {
            Console.WriteLine("Broj je nula.");
        }

        if (broj % 2 == 0)
        {
            Console.WriteLine("Broj je paran.");
        }
        else
        {
            Console.WriteLine("Broj je neparan.");
        }
    }
}