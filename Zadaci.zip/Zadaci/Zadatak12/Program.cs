﻿using System;

class Program
{
    static void Main()
    {
        double rezultat = 0;
        string unos;
        string operacija;

        Console.WriteLine("Dobro došli u kalkulator!");

        while (true)
        {
            Console.Write("Unesite prvi broj (ili napisite 'KRAJ' da izadjete.): ");
            unos = Console.ReadLine();
            if (unos.ToUpper() == "KRAJ") break;

            double broj1 = Convert.ToDouble(unos);

            Console.Write("Unesite drugi broj: ");
            double broj2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Odaberite operaciju: +, -, *, /, kvadrat, kub");
            operacija = Console.ReadLine();

            switch (operacija)
            {
                case "+":
                    rezultat = broj1 + broj2;
                    break;
                case "-":
                    rezultat = broj1 - broj2;
                    break;
                case "*":
                    rezultat = broj1 * broj2;
                    break;
                case "/":
                    rezultat = broj1 / broj2;
                    break;
                case "kvadrat":
                    rezultat = Math.Pow(broj1, 2);
                    break;
                case "kub":
                    rezultat = Math.Pow(broj1, 3);
                    break;
                default:
                    Console.WriteLine("Pogresna operacija. Pokusajte ponovo.");
                    continue;
            }

            Console.WriteLine($"Rezultat: {rezultat}");
            broj1 = rezultat; 
        }

        Console.WriteLine("Hvala što ste koristili kalkulator!");
    }
}