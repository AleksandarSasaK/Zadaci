﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> ParniBrojevi = new List<int>();
        List<int> NeparniBrojevi = new List<int>();
        int zbirpar = 0, zbirnepar = 0;

        Console.WriteLine("Molim vas unesite 10 cijelih brojeva:");

        for (int i = 0; i < 10; i++)
        {
            int broj = Convert.ToInt32(Console.ReadLine());
            if (broj % 2 == 0)
            {
                ParniBrojevi.Add(broj);
                zbirpar += broj;
            }
            else
            {
                NeparniBrojevi.Add(broj);
                zbirnepar += broj;
            }
        }

        ParniBrojevi.Sort();
        NeparniBrojevi.Sort();

        Console.WriteLine("Parni brojevi: " + string.Join(", ", ParniBrojevi));
        Console.WriteLine("Neparni brojevi: " + string.Join(", ", NeparniBrojevi));
        Console.WriteLine("Zbir parnih: " + zbirpar);
        Console.WriteLine("Zbir neparnih: " + zbirnepar);
    }
}