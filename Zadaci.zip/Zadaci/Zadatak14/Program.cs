﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Unesite par riječi, razmaknute korišćenjem space-a:");
        string unos = Console.ReadLine();
        string[] rijeci = unos.Split(' ');

        string najduzarijec = "";
        foreach (string rijec in rijeci)
        {
            if (rijec.Length > najduzarijec.Length)
            {
                najduzarijec = rijec;
            }
        }

        string obrnutredslova = new string(najduzarijec.ToCharArray().Reverse().ToArray());

        Console.WriteLine($"Najduža riječ je: {najduzarijec}");
        Console.WriteLine($"Obrnut red slova: {obrnutredslova}");
    }
}