﻿using System;

class Program
{
    static void Main(string[] args)
    {
        double poluprecnik;

        Console.Write("Unesite poluprecnik kruga: ");
        poluprecnik = Convert.ToDouble(Console.ReadLine());

        double Povrsina = Math.PI * Math.Pow(poluprecnik, 2);
        double Obim = (4.0 / 3.0) * Math.PI * Math.Pow(poluprecnik, 3);

        Console.WriteLine($"Povrsina kruga je: {Povrsina}");
        Console.WriteLine($"Obim kruga je: {Obim}");
    }
}