﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        bool RadPrograma = true;

        while (RadPrograma)
        {
            Console.WriteLine("Izaberite cijelinu racunala koja vas interesuje:");
            Console.WriteLine("1. Hardver");
            Console.WriteLine("2. Softver");
            Console.Write("Unesite vas izbor (1 ili 2): ");
            string izbor = Console.ReadLine();

            switch (izbor)
            {
                case "1":
                    PokaziOpcijezaHardver();
                    break;
                case "2":
                    PokaziopcijezaSoftver();
                    break;
                default:
                    Console.WriteLine("Pogresan Unos. Molim Vas odaberite 1 ili 2.");
                    break;
            }

            Console.Write("Da li želite da odaberete jos jednu opciju? (da/ne): ");
            RadPrograma = Console.ReadLine().Trim().ToLower() == "da";
        }
    }

    static void PokaziOpcijezaHardver()
    {
        var komponentehardvera = new Dictionary<string, string>
        {
            { "1", "CPU: CPU (centralna procesorska jedinica) je mozak racunara, odgovoran za izvršavanje instrukcija i izvodjenje proracuna." },
            { "2", "GPU: GPU (Graphics Processing Unit) upravlja prikazivanjem slika, video zapisa i 3D grafike, pomazuci u zadacima vizuelne obrade.." },
            { "3", "RAM: RAM (Random Access Memory) je privremena memorija koja se koristi za skladistenje podataka i instrukcija za aktivne procese i programe." },
            { "4", "Maticna ploca: Maticna ploca je glavna ploca koja povezuje i omogucava komunikaciju izmedju svih komponenti racunala." }
        };

        Console.WriteLine("Hardverske komponente:");
        foreach (var komponent in komponentehardvera)
        {
            Console.WriteLine($"{komponent.Key}. {komponent.Value.Split(':')[0]}");
        }

        Console.Write("Odaberite komponentu za vise informacija (1-4): ");
        string odabirkomponente = Console.ReadLine();

        if (komponentehardvera.ContainsKey(odabirkomponente))
        {
            Console.WriteLine(komponentehardvera[odabirkomponente]);
        }
        else
        {
            Console.WriteLine("Pogresan odabir.");
        }
    }

    static void PokaziopcijezaSoftver()
    {
        var komponentesoftvera = new Dictionary<string, string>
        {
            { "1", "Operativni sistem: Operativni sistem je softver koji upravlja hardverskim i softverskim resursima, pružajući korisnički interfejs i platformu za aplikacije." },
            { "2", "Antivirus: Antivirusni softver stiti racunar od zlonamjernog softvera, virusa i drugih sigurnosnih prijetnji." },
            { "3", "Uredski paket: Uredski paket je kolekcija alata za produktivnost, kao sto su programi za obradu teksta, proracunske tablice i softver za prezentacije." },
            { "4", "Web Pretrazivac: Web pretrazivac je softver koji se koristi za pristup i navigaciju internetom." }
        };

        Console.WriteLine("Softverske komponente:");
        foreach (var komponent in komponentesoftvera)
        {
            Console.WriteLine($"{komponent.Key}. {komponent.Value.Split(':')[0]}");
        }

        Console.Write("Odaberite komponentu za vise informacija (1-4): ");
        string odabirkomponente = Console.ReadLine();

        if (komponentesoftvera.ContainsKey(odabirkomponente))
        {
            Console.WriteLine(komponentesoftvera[odabirkomponente]);
        }
        else
        {
            Console.WriteLine("Pogresan unos.");
        }
    }
}