﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Molim Vas unesite vaše ime: ");
        string Ime = Console.ReadLine();

        Console.Write("Molim Vas unesite vaše prezime: ");
        string Prezime = Console.ReadLine();

        Console.Write("Molim Vas unesite vašu godinu rodjenja:  ");
        int GodinaRodjenja = int.Parse(Console.ReadLine());

        int TranutnaGodina = DateTime.Now.Year;
        int starost = TranutnaGodina - GodinaRodjenja;

        Console.WriteLine($"Pozdrav {Ime} {Prezime}, vi imate {starost} godina.");
    }
}