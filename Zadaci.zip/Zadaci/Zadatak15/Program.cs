﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Unesi dužinu stranice kvadrata: ");
        int duzina = int.Parse(Console.ReadLine());

        for (int i = 0; i < duzina; i++)
        {
            for (int j = 0; j < duzina; j++)
            {
                Console.Write("* ");
            }
            Console.WriteLine();
        }

        Console.WriteLine();

        int duplikvadrat = duzina * 2;
        for (int i = 0; i < duplikvadrat; i++)
        {
            for (int j = 0; j < duplikvadrat; j++)
            {
                Console.Write("* ");
            }
            Console.WriteLine();
        }
    }
}