﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Unesite četvorocifren broj: ");
        string input = Console.ReadLine();

        if (input.Length == 4 && int.TryParse(input, out _))
        {
            foreach (char digit in input)
            {
                Console.WriteLine(digit);
            }
        }
        else
        {
            Console.WriteLine("Unesite validan četvorocifren broj!");
        }
    }
}