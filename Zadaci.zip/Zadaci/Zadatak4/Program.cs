﻿using System;
class Program
{
    static void Main()
    {
        Random nasumica = new Random();
        int nasumicanbroj = nasumica.Next(1, 101); 
        Console.WriteLine("Nasumičan broj: " + nasumicanbroj);
    }
}