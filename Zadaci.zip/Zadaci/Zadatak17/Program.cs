﻿using System;
using System.Collections.Generic;

class Program
{
    private List<string> kategorije;
    private Random random;

    public Program()
    {
        kategorije = new List<string>
        {
            "Voće", "Države", "Životinje", "Boje", "Filmovi", "Knjige"
        };
        random = new Random();
    }

    public void Početakigre()
    {
        Console.WriteLine("Dobro došli u igru kategorija.");
        string odabranakategorija = Nasumicnakategorija();
        Console.WriteLine($"Odabrana kategorija: {odabranakategorija}");
        Igra(odabranakategorija);
    }

    private string Nasumicnakategorija()
    {
        int index = random.Next(kategorije.Count);
        return kategorije[index];
    }

    private void Igra(string kategorija)
    {
        HashSet<string> koristenerijeci = new HashSet<string>();
        string unos;

        Console.WriteLine($"Počnite nabrajati par primjera ove kategorije: {kategorija}");
        while (true)
        {
            Console.Write("Unesite riječ (ili napišire 'izlaz' da napustite igru): ");
            unos = Console.ReadLine();

            if (unos.ToLower() == "izlaz")
            {
                Console.WriteLine("Hvala na igranju!");
                break;
            }

            if (koristenerijeci.Contains(unos))
            {
                Console.WriteLine("Ova rijec je vec upotrijebljena, probajte opet.");
            }
            else
            {
                koristenerijeci.Add(unos);
                Console.WriteLine($"Vaša riječ je: {unos}");
            }
        }
    }

    static void Main(string[] args)
    {
        Program game = new Program();
        game.Početakigre();
    }
}