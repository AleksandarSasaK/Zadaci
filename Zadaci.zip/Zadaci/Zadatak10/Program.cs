﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Unesite broj redova: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Unesite broj kolona: ");
        int l = int.Parse(Console.ReadLine());

        int[,] matrix = new int[n, l];

        Console.WriteLine("Unesite elemente matrice:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < l; j++)
            {
                Console.Write($"Element [{i},{j}]: ");
                matrix[i, j] = int.Parse(Console.ReadLine());
            }
        }

        Console.WriteLine("Matrica je:");
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < l; j++)
            {
                Console.Write(matrix[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}