﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Unesite vaše ime: ");
        string ime = Console.ReadLine();

        Console.Write("Unesite vaše prezime: ");
        string prezime = Console.ReadLine();

        Console.Write("Unesite vaš uzrast: ");
        int starost = int.Parse(Console.ReadLine());

        Console.Write("Unesite čime se bavite: ");
        string profesija = Console.ReadLine();

        string status = starost >= 18 ? "odrasla osoba" : "maloljetnik/ica";

        Console.WriteLine($"Pozdrav {ime} {prezime}, vi ste {status}, i vi ste {profesija}.");
    }
}