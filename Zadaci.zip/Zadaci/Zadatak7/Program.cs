﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Unesite prvi broj: ");
        int PrviBroj = Convert.ToInt32(Console.ReadLine());

        Console.Write("Unesite drugi broj: ");
        int DrugiBroj = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine($"\nTablica mnozenja za prvi broj {PrviBroj}:");
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"{PrviBroj} x {i} = {PrviBroj * i}");
        }

        Console.WriteLine($"\nTablica mnozenja za drugi broj {DrugiBroj}:");
        for (int i = 1; i <= 10; i++)
        {
            Console.WriteLine($"{DrugiBroj} x {i} = {DrugiBroj * i}");
        }

        Console.WriteLine($"\nKvadrat broja {PrviBroj}: {PrviBroj * PrviBroj}");
        Console.WriteLine($"Kub broja {PrviBroj}: {PrviBroj * PrviBroj * PrviBroj}");

        Console.WriteLine($"\nKvadrat broja {DrugiBroj}: {DrugiBroj * DrugiBroj}");
        Console.WriteLine($"Kub broja {DrugiBroj}: {DrugiBroj * DrugiBroj * DrugiBroj}");
    }
}