﻿using System;

class Program
{
    static char[] ploca = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    static int igrac = 1; 
    static int izbor; 
    static int pobjeda = 0; 

    static void Main(string[] args)
    {
        do
        {
            Console.Clear(); 
            Console.WriteLine("Igrač1: X and Igrač2: O");
            Console.WriteLine("\n");
            Ploca();

            while (true)
            {
                Console.WriteLine($"Igrač {igrac}, unesi broj (1-9): ");
                izbor = int.Parse(Console.ReadLine());
                if (izbor >= 1 && izbor <= 9 && ploca[izbor] != 'X' && ploca[izbor] != 'O')
                    break;
                else
                    Console.WriteLine("Greška, pokusaj ponovo.");
            }

            ploca[izbor] = igrac == 1 ? 'X' : 'O';

            pobjeda = Provjerapobjede();

            igrac = (igrac % 2) + 1;

        } while (pobjeda != 1 && pobjeda != -1);

        Console.Clear();
        Ploca();
        if (pobjeda == 1)
            Console.WriteLine($"Igrač {--igrac} pobjedjuje!");
        else
            Console.WriteLine("Nerješeno!");
    }

    private static void Ploca()
    {
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {ploca[1]}  |  {ploca[2]}  |  {ploca[3]}  ");
        Console.WriteLine("_____|_____|_____ ");
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {ploca[4]}  |  {ploca[5]}  |  {ploca[6]}  ");
        Console.WriteLine("_____|_____|_____ ");
        Console.WriteLine("     |     |      ");
        Console.WriteLine($"  {ploca[7]}  |  {ploca[8]}  |  {ploca[9]}  ");
        Console.WriteLine("     |     |      ");
    }

    private static int Provjerapobjede()
    {
  
        for (int i = 1; i <= 7; i += 3)
            if (ploca[i] == ploca[i + 1] && ploca[i] == ploca[i + 2])
                return 1;

        for (int i = 1; i <= 3; i++)
            if (ploca[i] == ploca[i + 3] && ploca[i] == ploca[i + 6])
                return 1;

        if (ploca[1] == ploca[5] && ploca[1] == ploca[9])
            return 1;
        if (ploca[3] == ploca[5] && ploca[3] == ploca[7])
            return 1;

        foreach (char c in ploca)
        {
            if (c != 'X' && c != 'O')
                return 0;
        }
        return -1; 
    }
}