﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Unesite prvu grupu brojeva (razdvojite ih zarezom):");
        var PrvaGrupa = Console.ReadLine().Split(',').Select(int.Parse).ToArray();

        Console.WriteLine("Unesite drugu grupu brojeva (razdvojite ih zarezom):");
        var DrugaGrupa = Console.ReadLine().Split(',').Select(int.Parse).ToArray();

        var tempSet = PrvaGrupa;
        PrvaGrupa = DrugaGrupa;
        DrugaGrupa = tempSet;

        Array.Sort(PrvaGrupa);
        Array.Sort(DrugaGrupa);

        Console.WriteLine("Nova prva grupa u rastucem rasporedu: " + string.Join(", ", PrvaGrupa));
        Console.WriteLine("Druga nova grupa u rastucem rasporedu: " + string.Join(", ", DrugaGrupa));
    }
}