﻿using System;

class Program
{
    static void Main()
    {
        int prisustvo, kolokvij, integralniispit, projekat;
        Console.WriteLine("Unesite broj poena za prisustvo (0-20):");
        prisustvo = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Unesite broj poena za kolokvij (0-30):");
        kolokvij = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Unesite broj poena za Integralni ispit (0-30):");
        integralniispit = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Unesite broj poena za projekat (0-20):");
        projekat = Convert.ToInt32(Console.ReadLine());

        int ostvarenipoeni = prisustvo + kolokvij + integralniispit + projekat;
        string ocjena;

        if (ostvarenipoeni >= 95 && ostvarenipoeni <= 100)
            ocjena = "10";
        else if (ostvarenipoeni >= 85 && ostvarenipoeni < 95)
            ocjena = "9";
        else if (ostvarenipoeni >= 75 && ostvarenipoeni < 85)
            ocjena = "8";
        else if (ostvarenipoeni >= 65 && ostvarenipoeni < 75)
            ocjena = "7";
        else if (ostvarenipoeni >= 55 && ostvarenipoeni < 65)
            ocjena = "6";
        else
            ocjena = "5";

        Console.WriteLine($"Ukupan broj poena: {ostvarenipoeni}");
        Console.WriteLine($"Ocjena: {ocjena}");
    }
}