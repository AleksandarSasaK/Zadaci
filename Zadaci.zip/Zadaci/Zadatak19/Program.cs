﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        string[] rijeci = { "programming", "vjesalo", "kompjuter", "hardver", "softver" };
        Random random = new Random();
        string rijeckojasepogadja = rijeci[random.Next(rijeci.Length)];
        char[] unijetarijec = new string('_', rijeckojasepogadja.Length).ToCharArray();
        HashSet<char> slovakojasepogadjaju = new HashSet<char>();
        int pokusaj = 6;

        Console.WriteLine("Dobrodosli u igru pogadjanja!");

        while (pokusaj > 0 && new string(unijetarijec) != rijeckojasepogadja)
        {
            Console.WriteLine($"\nRiječ koja se pogadja je: {new string(unijetarijec)}");
            Console.WriteLine($"Broj pokušaja: {pokusaj}");
            Console.Write("Pogodite slovo: ");
            char nagadjanje = Console.ReadKey().KeyChar;
            Console.WriteLine();

            if (slovakojasepogadjaju.Contains(nagadjanje))
            {
                Console.WriteLine("Već ste pogodili to slovo.");
                continue;
            }

            slovakojasepogadjaju.Add(nagadjanje);

            if (rijeckojasepogadja.Contains(nagadjanje))
            {
                for (int i = 0; i < rijeckojasepogadja.Length; i++)
                {
                    if (rijeckojasepogadja[i] == nagadjanje)
                    {
                        unijetarijec[i] = nagadjanje;
                    }
                }
            }
            else
            {
                pokusaj--;
                Console.WriteLine($"Slovo '{nagadjanje}' nije u riječi.");
            }
        }

        if (new string(unijetarijec) == rijeckojasepogadja)
        {
            Console.WriteLine($"\nBravo. Pogodili ste riječ: {rijeckojasepogadja}");
        }
        else
        {
            Console.WriteLine($"\nGame over! Riječ je: {rijeckojasepogadja}");
        }
    }
}
