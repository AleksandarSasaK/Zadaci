﻿using System;

class Program
{
    static void Main()
    {
        string IspravanNalog = "user";
        string IspravnaLozinka = "1234";
        int pokusaji = 3;

        while (pokusaji > 0)
        {
            Console.Write("Unesite nalog: ");
            string nalog = Console.ReadLine();

            Console.Write("Unesite lozinku (četvorocifren broj): ");
            string lozinka = Console.ReadLine();

            if (nalog == IspravanNalog && lozinka == IspravnaLozinka)
            {
                Console.WriteLine($"Pozdrav, {IspravanNalog} dobro došli!");
                return;
            }
            else
            {
                pokusaji--;
                Console.WriteLine("Netačni podaci. Imate jos " + pokusaji + " pokusaja.");
            }
        }

        Console.WriteLine("Unijeli ste pogresne podatke.");
    }
}