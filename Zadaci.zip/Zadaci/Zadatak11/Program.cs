﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main()
    {
        List<int> serija1 = new List<int>();
        List<int> serija2 = new List<int>();
        List<int> serija3 = new List<int>();

        Console.WriteLine("Unesite 12 brojeva:");

        for (int i = 0; i < 12; i++)
        {
            int broj = Convert.ToInt32(Console.ReadLine());

            if (broj > 50)
            {
                serija1.Add(broj);
            }
            else if (broj <= 50 && broj > 0)
            {
                serija2.Add(broj);
            }
            else
            {
                serija3.Add(broj);
            }
        }

        serija1 = serija1.OrderBy(n => n).Take(4).ToList();
        serija2 = serija2.OrderBy(n => n).Take(4).ToList();
        serija3 = serija3.OrderBy(n => n).Take(4).ToList();

        Console.WriteLine("Serija 1 (Brojevi > 50): " + string.Join(", ", serija1));
        Console.WriteLine("Serija 2 (Brojevi <= 50 i > 0): " + string.Join(", ", serija2));
        Console.WriteLine("Serija 3 (Brojevi <= 0): " + string.Join(", ", serija3));
    }
}